# v0 Verification Project

This folder contains a minimal Next.js app configured to verify the `animated-emoji-4v` library in v0.

## Instructions

1.  **Download** this folder or zip it from your computer.
2.  **Upload** the zip file to v0 (or copy the file contents).
3.  **Run** it.

It acts as a "Proof of Concept" that the library installs correctly from GitHub.
